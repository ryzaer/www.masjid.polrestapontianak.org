<?php function sql_production(){
    // $p = \build::instance();
    // // sql production dan verified SSL
    // if($p->SCHEME == 'https' && $p->SQL['production']){
    //     $conn = explode(',',$p->SQL['production']);
    //     $p->SQL['host']=$conn[0];
    //     $p->SQL['user']=$conn[1];
    //     $p->SQL['pass']=$conn[2];
    //     $p->SQL['name']=$conn[3];
    // }
}