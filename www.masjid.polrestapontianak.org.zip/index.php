<?php 
require_once '../vendor/autoload.php';
build::base('app/setup.ini')->run();